from django.contrib import admin
from agent.models import agent
# Register your models here.
admin.site.register(agent)