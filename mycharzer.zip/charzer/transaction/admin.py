from django.contrib import admin
from transaction.models import transaction_model
# Register your models here.

admin.site.register(transaction_model)